#!/bin/bash
. /tmp/auto/release-$app.txt
eval $(python /usr/local/sbin/KM/parse_yaml.py /usr/local/sbin/KM/staging.yaml --cap)
read $PPTYPE
        case $PPTYPE in

        "ADMIN")
        ssh ubuntu@$IN1 -i /data/jenkins/.ssh/setup-keys.pem sudo apt-get update
        ssh ubuntu@$IN1 -i /data/jenkins/.ssh/setup-keys.pem sudo /etc/puppet/pp-apply.sh --versions $MODULE=$VERSION -y
        ssh ubuntu@$IN1 ( tail -f -n0 /var/log/parcelpoint/parcelpoint-$MODULE.log & ) | grep -q "Server Started"
        ;;
        "API")
	aws elb deregister-instances-from-load-balancer --load-balancer-name $API_LBS1 --instances $API_TGTS2
	aws elb deregister-instances-from-load-balancer --load-balancer-name $API_LBS2 --instances $API_TGTS2
	ssh ubuntu@$IN1 -i /data/jenkins/.ssh/setup-keys.pem sudo apt-get update
        ssh ubuntu@$IN1 -i /data/jenkins/.ssh/setup-keys.pem sudo /etc/puppet/pp-apply.sh --versions $MODULE=$VERSION -y
        ssh ubuntu@$IN1 ( tail -f -n0 /var/log/parcelpoint/parcelpoint-$MODULE.log & ) | grep -q "Server Started"
        aws elb register-instances-with-load-balancer --load-balancer-name $API_LBS1 --instances $API_TGTS2
        aws elb register-instances-with-load-balancer --load-balancer-name $API_LBS2 --instances $API_TGTS2
        sleep 30
        aws elb deregister-instances-from-load-balancer --load-balancer-name $API_LBS1 --instances $API_TGTS1
        aws elb deregister-instances-from-load-balancer --load-balancer-name $API_LBS2 --instances $API_TGTS1
	ssh ubuntu@$IN2 -i /data/jenkins/.ssh/setup-keys.pem sudo apt-get update
        ssh ubuntu@$IN2 -i /data/jenkins/.ssh/setup-keys.pem sudo /etc/puppet/pp-apply.sh --versions $MODULE=$VERSION -y
        ssh ubuntu@$IN1 ( tail -f -n0 /var/log/parcelpoint/parcelpoint-$MODULE.log & ) | grep -q "Server Started"
        aws elb register-instances-with-load-balancer --load-balancer-name $API_LBS1 --instances $API_TGTS1
        aws elb register-instances-with-load-balancer --load-balancer-name $API_LBS2 --instances $API_TGTS1
        ;;
        "APILITE")
        aws elbv2 deregister-targets --target-group-arn $APILITE_TGTGRPARN --targets Id=$APILITE_TGTS2
        ssh ubuntu@$IN1 -i /data/jenkins/.ssh/setup-keys.pem sudo apt-get update
        ssh ubuntu@$IN1 -i /data/jenkins/.ssh/setup-keys.pem sudo /etc/puppet/pp-apply.sh --versions $MODULE=$VERSION -y
        ssh ubuntu@$IN1 ( tail -f -n0 /var/log/parcelpoint/parcelpoint-$MODULE.log & ) | grep -q "Server Started"
        aws elbv2 register-targets --target-group-arn $APILITE_TGTGRPARN --targets Id=$APILITE_TGTS2
        sleep 30
        aws elbv2 deregister-targets --target-group-arn $APILITE_TGTGRPARN --targets Id=$APILITE_TGTS1
        ssh ubuntu@$IN2 -i /data/jenkins/.ssh/setup-keys.pem sudo apt-get update
        ssh ubuntu@$IN2 -i /data/jenkins/.ssh/setup-keys.pem sudo /etc/puppet/pp-apply.sh --versions $MODULE=$VERSION -y
        ssh ubuntu@$IN2 ( tail -f -n0 /var/log/parcelpoint/parcelpoint-$MODULE.log & ) | grep -q "Server Started"
        aws elbv2 register-targets --target-group-arn $APILITE_TGTGRPARN --targets Id=$APILITE_TGTS1
        ;;
        "APP")
        aws elb deregister-instances-from-load-balancer --load-balancer-name $APP_LBS1 --instances $APP_TGTS1
        aws elbv2 deregister-targets --target-group-arn $APP_TGTGRPARN --targets Id=$APP_TGTS1
        ssh ubuntu@$IN1 -i /data/jenkins/.ssh/setup-keys.pem sudo apt-get update
        ssh ubuntu@$IN1 -i /data/jenkins/.ssh/setup-keys.pem sudo /etc/puppet/pp-apply.sh --versions $MODULE=$VERSION -y
        ssh ubuntu@$IN1 ( tail -f -n0 /var/log/parcelpoint/parcelpoint-$MODULE.log & ) | grep -q "Server Started"
        aws elb register-instances-with-load-balancer --load-balancer-name $APP_LBS1 --instances $APP_TGTS1
        aws elbv2 register-targets --target-group-arn $APP_TGTGRPARN --targets Id=$APP_TGTS1
        ;;
        "ESB")
        aws elb deregister-instances-from-load-balancer --load-balancer-name $ESB_LBS1 --instances $ESB_TGTS2
        aws elbv2 deregister-targets --target-group-arn $ESB_TGTGRPARN --targets Id=$ESB_TGTS2
        ssh ubuntu@$IN2 -i /data/jenkins/.ssh/setup-keys.pem sudo apt-get update
        ssh ubuntu@$IN2 -i /data/jenkins/.ssh/setup-keys.pem sudo /etc/puppet/pp-apply.sh --versions $MODULE=$VERSION -y
        ssh ubuntu@$IN2 ( tail -f -n0 /var/log/parcelpoint/parcelpoint-$MODULE.log & ) | grep -q "Server Started"
        aws elb register-instances-with-load-balancer --load-balancer-name $ESB_LBS1 --instances $ESB_TGTS2
        aws elbv2 register-targets --target-group-arn $ESB_TGTGRPARN --targets Id=$ESB_TGTS2
        sleep 30
        aws elbv2 deregister-targets --target-group-arn $ESB_TGTGRPARN --targets Id=$ESB_TGTS1
        ssh ubuntu@$IN1 -i /data/jenkins/.ssh/setup-keys.pem sudo apt-get update
        ssh ubuntu@$IN1 -i /data/jenkins/.ssh/setup-keys.pem sudo /etc/puppet/pp-apply.sh --versions $MODULE=$VERSION -y
        ssh ubuntu@$IN1 ( tail -f -n0 /var/log/parcelpoint/parcelpoint-$MODULE.log & ) | grep -q "Server Started"
        aws elbv2 register-targets --target-group-arn $ESB_TGTGRPARN --targets Id=$ESB_TGTS1
        ;;
        esac
